//
//  ShoppingAppApp.swift
//  ShoppingApp
//
//  Created by Sangram Mohite on 16/06/23.
//

import SwiftUI

@main
struct ShoppingAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
