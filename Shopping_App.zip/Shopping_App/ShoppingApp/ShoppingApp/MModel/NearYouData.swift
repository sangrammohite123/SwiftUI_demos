//
//  NearYouData.swift
//  ShoppingApp
//
//  Created by Sangram Mohite on 16/06/23.
//

import Foundation

struct PlacesModel {
    var id: Int
    var name: String
    var time: String
    var rating:String
    var image: String
    
}
